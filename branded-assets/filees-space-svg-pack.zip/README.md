# filees:space — SVG logo pack

Files:
- filees-space-horizontal.svg — primary horizontal lockup
- filees-space-symbol.svg — stacked-folder symbol on transparent background
- filees-space-symbol-square.svg — square/favicon-style variant
- filees-space-fs.svg — compact `f:s` invariant
- filees-space-monochrome.svg — single-color horizontal variant

Brand colors:
- Navy: #0B1D3A
- Orange: #FF6A00

Technical notes:
- All lettering is converted to SVG paths.
- No external fonts, images, JavaScript, filters or embedded raster graphics.
- Backgrounds are transparent except in the square icon variant.
